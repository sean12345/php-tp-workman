<?php
return array(
    'DB_TYPE' => 'mysql', // 数据库类型
    'DB_HOST' => 'localhost', // 服务器地址 
    'DB_NAME' => 'demo', // 数据库名tp
    'DB_USER' => 'root', // 用户名tp
    'DB_PWD' => '', // 密码tp
    'DB_PORT' => 3306, // 端口
    'DB_PREFIX' => '', // 数据库表前缀
    'DB_CHARSET' => 'utf8', // 字符集
    'MODULE_ALLOW_LIST' => array(
        'Home',
    ),
    'LOG_TYPE'              =>  'File', 
    'LOG_LEVEL'  =>'EMERG,ALERT,CRIT,ERR',
    'SHOW_PAGE_TRACE' => false, //显示调试信息
    'DEFAULT_GROUP' => 'Home',
    'URL_MODEL' => 2,
    'LOAD_EXT_FILE' => 'common',
    'SESSION_AUTO_START'=>false,
);
