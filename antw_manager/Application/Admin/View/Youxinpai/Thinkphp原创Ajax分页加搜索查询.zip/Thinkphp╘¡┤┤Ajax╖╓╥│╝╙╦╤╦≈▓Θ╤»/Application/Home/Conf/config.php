<?php

$site_url = "http://" . $_SERVER['HTTP_HOST'] . "/";
return array(
    'URL_ROUTER_ON' => true,
    'URL_ROUTE_RULES' => array(
        '/^js/' => 'Index/js',
    ),
    'site_url' => $site_url,
    'TMPL_EXCEPTION_FILE' => './Application/Home/View/Public/404.html', //./Application/Home/View/Public/404.html
);
