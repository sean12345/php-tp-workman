<?php

namespace Home\Controller;

class BoxController extends CommonController {

    public function orders() {//成员详情
        $sql = "1=1";

        
        $keyword = trim(strip_tags(htmlspecialchars(strtolower(urldecode(iconv("gb2312","UTF-8",$_GET['keyword']))))));
        if (!empty($keyword)) {
            $sql .= " AND name like '%" . $keyword . "%'";
        }
        $count = M('js')->where($sql)->count();    //计算总数
        $Page = new \Think\PageAjax($count, 10);
//          
        $lists = M('js')->where($sql)->limit($Page->firstRow . ',' . $Page->listRows)->order('id DESC')->select();

        $this->assign("page", $Page->show());
        $this->assign("lists", $lists);
        $this->assign("keyword", $keyword);
        $this->display();
    }

}

?>
