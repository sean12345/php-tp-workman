<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head> 
        <title>Thinkphp原创Ajax分页加搜索查询</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
        <meta content="ajax分页演示,PHP无刷新分页教程,PHP分页搜索" name="keywords"/>
        <meta content="本文AJAX无刷新分页是参考Thinkphp仿淘宝分页跳转：http://www.sucaihuo.com/php/563.html,演示中有两个查询条件，分页和搜索关键字，你还可以添加其他分页参数。" name="description"/>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <link rel="stylesheet" type="text/css" href="http://www.sucaihuo.com/jquery/css/common.css" />
        <script src="/jquery/6/637/demo/Public/js/jquery.js" type="text/javascript"></script>
        <script type="text/javascript">
            var url_ajax = "/jquery/6/637/demo/Box/orders";
            $(function() {
                $("#ajax_lists").delegate(".pager a", "click", function() {
                    var page = $(this).attr("data-page");
                    getPage(page);
                })
                getPage(1);

            })
            function getPage(page) {
                 $("#ajax_lists").html("<div class='loading'><img src='/jquery/6/637/demo/Public/images/loading.gif' alt='loading'></div>");
                var keyword = $("#keyword").val();
                $.get(url_ajax, {keyword: keyword, p: page}, function(data) {
                    $('#ajax_lists').html(data);
                })
            }
        </script>
    </head>
    <body>
        <div class="head">
            <div class="head_inner clearfix">
                <ul id="nav">
                    <li><a href="http://www.sucaihuo.com">首 页</a></li>
                    <li><a href="http://www.sucaihuo.com/templates">网站模板</a></li>
                    <li><a href="http://www.sucaihuo.com/js">网页特效</a></li>
                    <li><a href="http://www.sucaihuo.com/php">PHP</a></li>
                    <li><a href="http://www.sucaihuo.com/site">精选网址</a></li>
                </ul>
                <a class="logo" href="http://www.sucaihuo.com"><img src="http://www.sucaihuo.com/Public/images/logo.jpg" alt="素材火logo" /></a>
            </div>
        </div>
        <div class="container">
            <div class="demo">
                <h2 class="title"><a href="http://www.sucaihuo.com/js/637.html">教程：Thinkphp原创Ajax分页加搜索查询</a></h2>
                <input type="text" class="input" id="keyword" value="" placeholder="请输入搜索关键词"/> <input type="button" class="btn" value="搜索" onclick="getPage(1)" />
                <div class="content" id="ajax_lists"></div>
            </div>
        </div>
        <div class="foot">
            Powered by sucaihuo.com  本站皆为作者原创，转载请注明原文链接：<a href="http://www.sucaihuo.com" target="_blank">www.sucaihuo.com</a>
        </div>

    </body>
</html>

<p class="vad">
    <a href="http://www.sucaihuo.com/" target="_blank">sucaihuo.com</a>
    <a href="http://www.sucaihuo.com/js/637.html" target="_blank">说 明</a>
    <a href="http://www.sucaihuo.com/js/637.html" target="_blank">下 载</a>
</p>
<style type="text/css">
    .vad { margin: 20px 0 5px; font-family: Consolas,arial,宋体,sans-serif; text-align:center;}
    .vad a { display: inline-block; height: 36px; line-height: 36px; margin: 0 5px; padding: 0 50px; font-size: 14px; text-align:center; color:#eee; text-decoration: none; background-color: #222;}
    .vad a:hover { color: #fff; background-color: #000;}
    .thead { width: 728px; height: 90px; margin: 0 auto; border-bottom: 40px solid #fff;}
</style>
<div style="width:728px;margin:0 auto">
    <script type="text/javascript">
        /*700*90 创建于 2015-06-27*/
        var cpro_id = "u2176575";
    </script>
    <script src="http://cpro.baidustatic.com/cpro/ui/c.js" type="text/javascript"></script>
</div>
<!-- 以上是统计及其他信息，与演示无关，不必理会 -->