<?php if (!defined('THINK_PATH')) exit();?>

<div class="table-responsive" >
    <?php if(!empty($lists)): ?><table class="table_parameters" width="100%">
            <thead>
                <tr class="tr_head">
                    <th width='45px' class="center">id</th>
                    <th>名称</th>
                </tr>
            </thead>
            <tbody>
            <?php if(is_array($lists)): foreach($lists as $key=>$row): ?><tr>
                    <td  class="center"><?php echo ($row["id"]); ?></td>
                    <td class="name"><a target="_blank" href="http://www.sucaihuo.com/js/<?php echo ($row["id"]); ?>.html"><?php echo ($row["name"]); ?></a></td>
                </tr><?php endforeach; endif; ?>
            </tbody>
        </table>
        <?php else: ?>
        <div class='loading'>没有符合条件的记录！</div><?php endif; ?>
</div>
<div class="pager" style="margin:30px 0 0 0"><?php echo ($page); ?></div>